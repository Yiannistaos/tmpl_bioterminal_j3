# BioTerminal Joomla! 3.x Template - Terminal Style Landing Page

A Joomla! template with a simple terminal-style that uses the [WinBox](https://github.com/nextapps-de/winbox) library.

The video is produced by Brad Traversy and you can see it on Youtube (https://www.youtube.com/watch?v=jQCk2yo10YY)"

[Joomla! Demo](https://joomla.dokim.es)

### Screenshot from parameters

In the parameters you can add your brand name, the navigation menu links with their content, and your social media links.

<img src="https://temp.web357.com/images/tmpl_bioterminal-parameters.png" alt="BioTerminal Joomla! Template - Parameters" aria-label='Web357.com' />